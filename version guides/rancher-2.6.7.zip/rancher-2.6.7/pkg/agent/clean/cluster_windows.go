package clean

func Cluster() error {
	return nil
}
