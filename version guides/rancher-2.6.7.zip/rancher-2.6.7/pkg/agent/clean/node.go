package clean

const (
	NodeCleanupContainerName = "cattle-node-cleanup"
	AgentImage               = "AGENT_IMAGE"
	PrefixPath               = "PREFIX_PATH"
	WindowsPrefixPath        = "WINDOWS_PREFIX_PATH"
)
