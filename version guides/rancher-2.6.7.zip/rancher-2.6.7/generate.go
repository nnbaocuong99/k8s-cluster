//go:generate go run pkg/codegen/generator/cleanup/main.go
//go:generate go run pkg/codegen/main.go

package main
